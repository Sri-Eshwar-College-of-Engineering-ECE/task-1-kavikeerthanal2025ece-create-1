package assignment4;

class Employee {
    String name;
    String address;
    double salary;
    String jobTitle;

    Employee(String name, String address, double salary, String jobTitle) {
        this.name = name;
        this.address = address;
        this.salary = salary;
        this.jobTitle = jobTitle;
    }

    void calculateBonus() {
        System.out.println("Bonus = " + (salary * 0.10));
    }

    void performanceReport() {
        System.out.println(name + " Performance: Excellent");
    }

    void manageProject() {
        System.out.println(name + " is managing company projects.");
    }

    void display() {
        System.out.println("\nName : " + name);
        System.out.println("Address : " + address);
        System.out.println("Salary : " + salary);
        System.out.println("Job Title : " + jobTitle);
    }
}

class Manager extends Employee {

    Manager(String name, String address, double salary) {
        super(name, address, salary, "Manager");
    }

    void manageProject() {
        System.out.println(name + " manages the entire project.");
    }
}

class Developer extends Employee {

    Developer(String name, String address, double salary) {
        super(name, address, salary, "Developer");
    }

    void performanceReport() {
        System.out.println(name + " developed high-quality software.");
    }
}

class Programmer extends Employee {

    Programmer(String name, String address, double salary) {
        super(name, address, salary, "Programmer");
    }

    void calculateBonus() {
        System.out.println("Bonus = " + (salary * 0.15));
    }
}

public class EmployeeDemo {

    public static void main(String[] args) {

        Manager m = new Manager("Rahul", "Chennai", 80000);
        Developer d = new Developer("Priya", "Salem", 60000);
        Programmer p = new Programmer("Arun", "Coimbatore", 50000);

        m.display();
        m.calculateBonus();
        m.performanceReport();
        m.manageProject();

        d.display();
        d.calculateBonus();
        d.performanceReport();
        d.manageProject();

        p.display();
        p.calculateBonus();
        p.performanceReport();
        p.manageProject();
    }
}
